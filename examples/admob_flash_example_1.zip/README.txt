This folder contains the basic files you will need to create the swf file that you will later use for creating your APK.

The admob_v1.swc is simply the admob_v1.ane file that has been renamed. The files are otherwise identical, but flash will not read the ane. You will need to add the swc to your library path and set the linkage to "external" (refer to the enclosed .fla as an example)

The yourapp-app.xml file contains the additional tags required for the ane. These are the <extensions> tag and the <activity> tag (inside the <manifestAdditions> tag).

The Main.as contains the admob functions you will need to include in your app to initialize, show, hide, and close the ad module.

Thank you Emil for saving us all untold hours of work creating my own admob.ane!